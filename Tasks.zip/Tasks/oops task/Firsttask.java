import java.util.Scanner;

public class Firsttask {
    public static void greet(String demo) {

        System.out.println("Hello"+ demo);
    }
    public static void main(String[] args) {
        greet("");
        greet(" Sansa");
    }
}
